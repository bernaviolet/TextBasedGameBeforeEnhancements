# Amanda Violet Bern

def main():

    # Dictionary containing rooms and directions
    rooms = {
        'Great Hall': {'South': 'Greenhouse', 'North': 'Bathhouse', 'East': 'Apothecary Room', 'West': 'Western Foyer',
                       'Item': 'no items'},
        'Greenhouse': {'North': 'Great Hall', 'East': 'Horticultural Room', 'Item': 'Insect Killing Granules'},
        'Horticultural Room': {'West': 'Greenhouse', 'Item': 'Horticultural Oil'},
        'Bathhouse': {'South': 'Great Hall', 'East': 'Basement', 'Item': 'Insecticidal Soap Bubbles'},
        'Western Foyer': {'East': 'Great Hall', 'Item': 'Rubbing Alcohol'},
        'Apothecary Room': {'North': 'Solar Room', 'West': 'Great Hall', 'Item': 'White Vinegar'},
        'Solar Room': {'South': 'Apothecary Room', 'Item': 'Mighty Spray Bottle'},
        'Basement': {'West': 'Bathhouse', 'Item': 'Argentine Ants'}
    }  

    current_room = 'Great Hall'  # set beginning room to Great Hall
    inventory_items = []         # set inventory items to an empty list

    def game_instructions():     # Welcomes user to game and shows user game instructions and game commands
        print('Welcome to Succulent City Adventure Game!')
        print('You are the Black Knight. The Silver Queen needs you to save Succulent City from the '
              'Argentine Ants.')
        print("To win the game, collect 6 items and defeat the Argentine Ants.")
        print('Move commands: go South, go North, go East, go West')
        print('Add to inventory command: get (item name)')
        print('Quit game command: quit')
        print('-'*20)

    def moves(direction, room='Great Hall'):   # Calculates user's movement between rooms
        if room == 'Great Hall':               # Calculates which room is the user's current room
            if direction == 'South':
                print("It's so warm in here.")
                return rooms[room]['South']   # returns user's new room
            elif direction == 'North':
                print('*Bloop Bloop Pop*')
                return rooms[room]['North']
            elif direction == 'East':
                print("Wow, there's a lot of bottles in here.")
                return rooms[room]['East']
            elif direction == 'West':
                return rooms[room]['West']
        elif room == 'Greenhouse':
            if direction == 'North':
                return rooms[room]['North']
            elif direction == 'South':
                print('You walked into a wall.')
                print()
                print('Please choose a different direction.')
                return room
            elif direction == 'East':
                print('Wow, there is a lot of plant stuff in here.')
                return rooms[room]['East']
            elif direction == 'West':
                print('You walked into a wall.')
                print()
                print('Please choose a different direction.')
                return room
        elif room == 'Horticultural Room':
            if direction == 'North':
                print("Oof, that's a wall.")
                print()
                print('Please enter a different direction.')
                return room
            elif direction == 'South':
                print('You see a pretty view but you cannot go out the window.')
                print()
                print('Please choose a different direction.')
                return room
            elif direction == 'East':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'West':
                print("It's still hot in here.")
                return rooms[room]['West']
        elif room == 'Bathhouse':
            if direction == 'North':
                print("Ugh, you got sprayed with water from the shower.")
                print()
                print('Please choose a different direction.')
                return room
            elif direction == 'South':
                print('You are in', end=' ')
                return rooms[room]['South']
            elif direction == 'East':            # room is basement and user either wins or loses the game
                if len(inventory_items) != 6:    # if user does not have all six items, they lose
                    print('Oh no!')
                    print('You did not collect all 6 items and were unable to defend yourself.')
                    print('The Argentine Ants have consumed you.')
                    print('You have failed The Silver Queen and the citizens of Succulent City.')
                    print('Game Over')
                    exit()
                elif len(inventory_items) == 6:  # if the user has all six items, they win
                    print('LOOK OUT!!!')
                    print('*Spray spray spray*')
                    print('You have defeated the Argentine Ants and saved the citizens of Succulent City!')
                    print('The Silver Queen thanks you with riches beyond imagination.')
                    print('Congratulations!')
                    exit()
            elif direction == 'West':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
        elif room == 'Western Foyer':
            if direction == 'North':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'South':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'East':
                print('You are in', end=' ')
                return rooms[room]['East']
            elif direction == 'West':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
        elif room == 'Apothecary Room':
            if direction == 'North':
                print('The sky looks so beautiful in here.')
                return rooms[room]['North']
            elif direction == 'South':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'East':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'West':
                return rooms[room]['West']
        elif room == 'Solar Room':
            if direction == 'North':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'South':
                return rooms[room]['South']
            elif direction == 'East':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'West':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room

    def get_item(room, item):                           # adds items to user's inventory
        if room == 'Greenhouse':                        # calculates user's current room
            if item == 'Insect Killing Granules':       # checks that user input is the correct item
                return rooms['Greenhouse']['Item']      # returns the room item
            elif item != 'Insect Killing Granules':     # if user input is not the correct item
                print('Please enter a valid command.')  # outputs error message
                return ()
        elif room == 'Horticultural Room':
            if item == 'Horticultural Oil':
                return rooms['Horticultural Room']['Item']
            elif item != 'Horticultural Oil':
                print('Please enter a valid command.')
                return ()
        elif room == 'Bathhouse':
            if item == 'Insecticidal Soap Bubbles':
                return rooms['Bathhouse']['Item']
            elif item != 'Insecticidal Soap Bubbles':
                print('Please enter a valid command.')
                return ()
        elif room == 'Western Foyer':
            if item == 'Rubbing Alcohol':
                return rooms['Western Foyer']['Item']
            elif item != 'Rubbing Alcohol':
                print('Please enter a valid command.')
                return ()
        elif room == 'Apothecary Room':
            if item == 'White Vinegar':
                return rooms['Apothecary Room']['Item']
            elif item != 'White Vinegar':
                print('Please enter a valid command.')
                return ()
        elif room == 'Solar Room':
            if item == 'Mighty Spray Bottle':
                return rooms['Solar Room']['Item']
            elif item != 'Mighty Spray Bottle':
                print('Please enter a valid command.')
                return ()

    def show_status():  # outputs the user's current room, inventory items, and what item they can see in their room
        print('You are in the', current_room)
        print('Inventory:', inventory_items)
        print('You see {}'.format(rooms[current_room]['Item']))
        print('-'*20)

    game_instructions()  # call game_instructions function to run
    play_response = input('Would you like to play? (Y/N)\033[1m \n').upper()  # converts user input to bold
    print('\033[0m')  # converts text back to light
    if play_response == 'Y':  # starts the game
        print('Excellent!')
        show_status()  # calls show_status() to output information to user
    else:
        print('Okay, maybe next time.')  # does not start game

    while play_response == 'Y':  # if user inputs Y game begins
        user_input = input('What do you want to do? (Enter "go North", "go South", "go East", "go West", '
                           'get (item name) or "quit" to quit)\033[1m \n').lower()  # gets user command, converts to bold
        print('\033[0m')  # converts text back to light
        if user_input == 'quit':  # ends game whenever user enters quit command
            print('Thank you for playing!')
            break
        elif user_input == 'go north':  # calculates user moves using moves function
            current_room = moves('North', current_room)
            show_status()  # calls show_status() to output information to user
        elif user_input == 'go south':
            current_room = moves('South', current_room)
            show_status()
        elif user_input == 'go west':
            current_room = moves('West', current_room)
            show_status()
        elif user_input == 'go east':
            current_room = moves('East', current_room)
            show_status()
# get item commands
        elif user_input == 'get insect killing granules':
            if 'Insect Killing Granules' not in inventory_items:  # prevents user from adding same item to inventory
                inventory_items.append(get_item(current_room, 'Insect Killing Granules'))  # adds new item to list
                print('Insect Killing Granules added to inventory!')
                show_status()  # calls show_status() to output information to user
            else:  # outputs that the user already added the item to inventory
                print('Insect Killing Granules are already in your inventory.')
                show_status()
        elif user_input == 'get horticultural oil':
            if 'Horticultural Oil' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Horticultural Oil'))
                print('Horticultural Oil added to your inventory!')
                show_status()
            else:
                print('Horticultural Oil is already in your inventory.')
                show_status()
        elif user_input == 'get insecticidal soap bubbles':
            if 'Insecticidal Soap Bubbles' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Insecticidal Soap Bubbles'))
                print('Insecticidal Soap Bubbles added to your inventory!')
                show_status()
            else:
                print('Insecticidal Soap Bubbles are already in your inventory.')
                show_status()
        elif user_input == 'get rubbing alcohol':
            if 'Rubbing Alcohol' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Rubbing Alcohol'))
                print('Rubbing Alcohol added to your inventory!')
                show_status()
            else:
                print('Rubbing Alcohol is already in your inventory.')
                show_status()
        elif user_input == 'get white vinegar':
            if 'White Vinegar' not in inventory_items:
                inventory_items.append(get_item(current_room, 'White Vinegar'))
                print('White Vinegar added to your inventory!')
                show_status()
            else:
                print('White Vinegar is already in your inventory.')
                show_status()
        elif user_input == 'get mighty spray bottle':
            if 'Mighty Spray Bottle' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Mighty Spray Bottle'))
                print('Mighty Spray Bottle added to your inventory!')
                show_status()
            else:
                print('Mighty Spray Bottle is already in your inventory.')
                show_status()
        else:
            print('Please enter a a valid command.')  # if an unrecognized command is input by user
            show_status()


if __name__ == '__main__':
    main()
